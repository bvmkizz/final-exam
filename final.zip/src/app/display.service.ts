import { Injectable } from '@angular/core';
import { User } from './interfaces/User';

@Injectable({
  providedIn: 'root'
})
export class DisplayService {
  displayUsers(users: User[]): void {
    users.forEach(user => {
      console.log(`User: ${user.firstName} ${user.lastName}`);
    });

    console.log("Array is displayed by Display service");
  }
}
