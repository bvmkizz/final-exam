import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import { Input } from '@angular/core';
import { ParentUser } from '../interfaces/ParentUser';

import { ChildUser } from '../interfaces/ChildUser';

import { FormBuilder, Validators } from '@angular/forms';
import { User } from '../interfaces/User';
import { DisplayService } from '../display.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  @Input() parentUsers!: ParentUser[];

  @Output() output: EventEmitter<ChildUser[]> = new EventEmitter();

  outputData() {
    this.output.emit(this.childUserList);
  }

  ngOnInit(): void {
    this.outputData();
  }

  userForm = this.fb.group({
    id: ["", [Validators.required]],
    firstName: ["", [Validators.required, Validators.minLength(3)]],
    lastName: ["", [Validators.required, Validators.minLength(3)]],
    dateOfBirth: ["", [Validators.required]],
    phoneNumber: ["", [Validators.required, Validators.minLength(9)]],
    email: ["", [Validators.required, Validators.minLength(8)]]
  })

  addUser() {
    const value = this.userForm.value;
    const newUser: User = {
      id: value.id as string,
      firstName: value.firstName as string,
      lastName: value.lastName as string,
      dateOfBirth: value.lastName as string,
      phoneNumber: value.phoneNumber as string,
      email: value.email as string
    } 
    this.childUserList.push(newUser);
  }
  
  displayUsersArray(users: any[]): void {
    this.ds.displayUsers(users); 
  }

  childUserList: ChildUser[] = [
    {
      id: "1",
      firstName: "Emma",
      lastName: "Johnson",
      dateOfBirth: "2010-03-08",
      phoneNumber: "1112223333",
      email: "emma.johnson@example.com",
    },
    {
      id: "2",
      firstName: "Liam",
      lastName: "Miller",
      dateOfBirth: "2012-07-12",
      phoneNumber: "4445556666",
      email: "liam.miller@example.com",
    },
    {
      id: "3",
      firstName: "Olivia",
      lastName: "Davis",
      dateOfBirth: "2008-11-05",
      phoneNumber: "7778889999",
      email: "olivia.davis@example.com",
    },
    {
      id: "4",
      firstName: "Noah",
      lastName: "Brown",
      dateOfBirth: "2014-05-20",
      phoneNumber: "1234567890",
      email: "noah.brown@example.com",
    },
    {
      id: "5",
      firstName: "Ava",
      lastName: "Martinez",
      dateOfBirth: "2011-09-15",
      phoneNumber: "9876543210",
      email: "ava.martinez@example.com",
    },
  ];


  constructor(private fb: FormBuilder, private ds: DisplayService) {}
}
