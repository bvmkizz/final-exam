import { Component } from '@angular/core';

import { ParentUser } from './interfaces/ParentUser';
import { ChildUser } from './interfaces/ChildUser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Guka Mamadashvili';

  getData($event: ChildUser[]) {
    this.childUserList = $event;
  }

  userList = [
    {
      firstName: "Maria",
      lastName: "Baramadze",
      age: 19,
    },
    {
      firstName: "Gojo",
      lastName: "Satoru",
      age: 28
    },
    {
      firstName: "Lionel",
      lastName: "Messi",
      age: 36
    },
    {
      firstName: "Cristiano",
      lastName: "Ronaldo",
      age: 38
    },
    {
      firstName: "Nick",
      lastName: "Khaindrava",
      age: 19
    }
  ];

    parentUserList: ParentUser[] = [
      {
        id: "1",
        firstName: "John",
        lastName: "Doe",
        dateOfBirth: "1985-05-15",
        phoneNumber: "1234567890",
        email: "johndoe@example.com",
      },
      {
        id: "2",
        firstName: "Alice",
        lastName: "Smith",
        dateOfBirth: "1990-10-25",
        phoneNumber: "9876543210",
        email: "alice.smith@example.com",
      },
      {
        id: "3",
        firstName: "Michael",
        lastName: "Johnson",
        dateOfBirth: "1978-12-03",
        phoneNumber: "5551234567",
        email: "michael.johnson@example.com",
      },
      {
        id: "4",
        firstName: "Emily",
        lastName: "Brown",
        dateOfBirth: "1988-08-20",
        phoneNumber: "3219876543",
        email: "emily.brown@example.com",
      },
      {
        id: "5",
        firstName: "Sophia",
        lastName: "Garcia",
        dateOfBirth: "1995-04-10",
        phoneNumber: "7894561230",
        email: "sophia.garcia@example.com",
      },
    ];
  
  childUserList: ChildUser[] = [];

}
